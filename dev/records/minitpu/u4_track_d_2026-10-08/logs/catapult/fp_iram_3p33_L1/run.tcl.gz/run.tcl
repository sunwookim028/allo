# Project root directory
set sfd [file dir [info script]]

# Create new solution
solution new -state initial
solution options defaults
solution options set /Input/CppStandard c++11

# Add source files
solution file add "$sfd/kernel.cpp" -type C++

# Set top-level design function
directive set -DESIGN_HIERARCHY top

# Set clock constraints
directive set -CLOCKS {clk {-CLOCK_PERIOD 3.330}}

# Set output language
solution options set /Output/OutputVerilog true
solution options set /Output/OutputVHDL false

directive set -IO_MODE super
directive set -SPECULATE true
solution library add nangate-45nm_beh

# Flow
go analyze
go compile

solution library add ccs_sample_mem
go architect
cycle set {v8.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v8.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v9.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v10.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v11.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v12.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v13.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v0.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v1.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v2.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v3.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v4.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v5.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v6.Pop()} -equal 1  ;# latency=1 on fetch_0
cycle set {v14.Push()} -from {v7.Pop()} -equal 1  ;# latency=1 on fetch_0
go assembly
go extract

exit
